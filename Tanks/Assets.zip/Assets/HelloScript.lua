-- Hello, Script !

print("Hello, Script!");